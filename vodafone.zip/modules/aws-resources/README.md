
#  Terraform Modules - AWS resources

Description

This Terraform module creates an AWS infrastructure resources. The components created include:

* One AWS VPC
* One AWS subnet
* One IGW
* One AWS Route Table
* One SG
* One EC2 - update AWS Limux lates AMI
* One NIC
* One EIP
* One TGW - optionally
* One SSH-Key-pair and download it locally
